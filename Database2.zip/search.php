<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
    body{
        text-align:center;
    }
    </style>
</head>
<body>
    <form action="search.php" method="GET">
    <input type="text" placeholder="Työntekijän nimi" name="name" value='<?php echo $_GET["name"]?>'>
    <input type="submit">
    </form>
    <?php

    include 'yhteys.php';
    $etunimi = $_GET["name"];

    $result = $connection->query("SELECT * FROM tyontekijat WHERE Etunimi LIKE '%$etunimi%'"); 

    if($result->num_rows >0)
        while($row = $result->fetch_assoc()) {
            echo $row["Etunimi"]. "<br>";
        }else{
            echo "No results";
        }
        $connection -> close();
        echo "<script>console.log('Connection to the database closed');</script>"; 
    ?>
</body>
</html>