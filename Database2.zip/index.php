<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Page Title</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
    th{
        border: solid black 1px;
        border-right: none;
        padding: 5px;
        
    }
    td{
        border-bottom: solid black 1px;
        border-left: dashed black 1px;
    }
    </style>
</head>
<body>
<h2>Lisää työntekijä</h2>
    <form action="processPost.php" method="POST">
    Työntekijän nimi <input type="text" name="name"><br>
    Työntekijän palkka <input type="number" name="pay"><br>
    Työntekijän syntymäaika <input type="date" name="bday"><br>
    Työntekijän osasto <input type="text" name="depart">
    <input type="submit">
    </form>

<h2>Hae työntekijää</h2>
<form action="search.php" method="GET">
<input type="text" placeholder="Työntekijän nimi" name="name">
<input type="submit">
</form>

</body> 

</html>