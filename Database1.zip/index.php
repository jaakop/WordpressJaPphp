<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Page Title</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
    th{
        border: solid black 1px;
        border-right: none;
        padding: 5px;
        
    }
    td{
        border-bottom: solid black 1px;
        border-left: dashed black 1px;
    }
    </style>
</head>
<body>
<h2>Lisää työntekijä</h2>
    <form action="processPost.php" method="POST">
    Työntekijän nimi <input type="text" name="name"><br>
    Työntekijän palkka <input type="number" name="pay"><br>
    Työntekijän syntymäaika <input type="date" name="bday"><br>
    Työntekijän osasto <input type="text" name="depart">
    <input type="submit">
    </form>
</body> 
<table cellspacing=0 cellpadding=0>
<tr>
<th>Etunimi</th><th>Palkka</th><th>Syntymäaika</th><th style="border-right: solid black 1px;">Osasto</th>
</tr>
<?php
include 'yhteys.php';
$result = $connection->query("SELECT Etunimi, Palkka, Syntymaaika, Osasto FROM tyontekijat");
while($row = $result->fetch_assoc()){
    echo "<tr >";
    $i = 0;
    $len = count($row);
    foreach($row as $value){
        if($i == $len-1){
        echo '<td style="border-right: solid black 1px;">' . $value."</td>";
    }elseif($i == 0){
        echo '<td style="border-left: solid black 1px;">' . $value."</td>";
    }
    else{
        echo "<td>" . $value ."</td>";
    }
        $i++;
    }echo "</tr><br>";
}
$result->free();
$connection ->close();
echo "<script>console.log('Connection to the database closed')</script>";
?></table>
</html>