<?php
$host = "localhost";
$username = "root";
$password = "";
$databaseName = "omadatabase";
$port = "3306";

$connection = mysqli_connect($host, $username, $password, $databaseName, $port); 
 
// Tsekataan onnistuuko 
if (!$connection) { 
    die("Yhteys ei onnistunut " . mysqli_connect_error()); 
} 
echo "<script>console.log('Database connection established');</script>"; 
?>