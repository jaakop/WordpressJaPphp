<?php
include 'yhteys.php';


$name = $_POST["name"];
$pay = $_POST["pay"];
$bday = $_POST['bday'];
$depart = $_POST["depart"];

$query = "INSERT INTO tyontekijat(Etunimi, Palkka, Syntymaaika, Osasto) VALUES ('$name', $pay, '$bday', '$depart');";

$connection->query($query);
mysqli_close($connection);
echo "<script>console.log('Database connection closed');</script>";
header("Location: /");
?>